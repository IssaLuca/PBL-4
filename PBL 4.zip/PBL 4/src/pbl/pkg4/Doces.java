
package pbl.pkg4;

import java.util.ArrayList;

public class Doces extends Produtos{
    protected String tipo;

    public Doces(ArrayList totalprodutos) {
        super(totalprodutos);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    @Override
    public void alteraEntrega (String dia){
        if(dia.equalsIgnoreCase("Sabado") || dia.equalsIgnoreCase("Domingo")){
            this.entrega = this.entrega * 1.2;
        }
    }
}
