
package pbl.pkg4;

import java.util.ArrayList;

public class Frios extends Produtos {
    
    public Frios(ArrayList totalprodutos) {
        super(totalprodutos);
    }
    
    @Override
    public void alteraTempoEspera(String dia){
    if(dia.equalsIgnoreCase("Domingo")){
        this.entrega = this.entrega * 1.1;
    }
    }
}
