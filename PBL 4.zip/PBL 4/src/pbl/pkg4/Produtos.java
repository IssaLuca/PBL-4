/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbl.pkg4;

import java.util.ArrayList;

/**
 *
 * @author Luca Issa
 */
public abstract class Produtos {
    protected double preço;
    protected int validade;
    protected String especs;
    protected double entrega;
    protected ArrayList totalprodutos;

    public Produtos(ArrayList totalprodutos) {
        this.totalprodutos = totalprodutos;
    }
    
    public double getPreço() {
        return preço;
    }

    public void setPreço(double preço) {
        this.preço = preço;
    }

    public int getValidade() {
        return validade;
    }

    public void setValidade(int validade) {
        this.validade = validade;
    }

    public String getEspecs() {
        return especs;
    }

    public void setEspecs(String especs) {
        this.especs = especs;
    }

    public double getEntrega() {
        return entrega;
    }

    public void setEntrega(double entrega) {
        this.entrega = entrega;
    }

    public ArrayList getTotalprodutos() {
        return totalprodutos;
    }

    public void setTotalprodutos(ArrayList totalprodutos) {
        this.totalprodutos = totalprodutos;
    }
    
    
    
    public void alteraEntrega(String dia){}
    
    public void alteraCompra(String dia){}
    
    public void alteraTempoEspera(String dia){}
   
    
    }
    

