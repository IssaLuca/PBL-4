
package pbl.pkg4;

import java.util.ArrayList;

public class Paezinhos extends Produtos {
    protected String sabor;

    public Paezinhos(ArrayList totalprodutos) {
        super(totalprodutos);
    }
    
    @Override
    public void alteraCompra(String dia){
       if(dia.equalsIgnoreCase("Sabado") || dia.equalsIgnoreCase("Domingo")){
            this.entrega = this.entrega * 1.15;
        }
    }

    public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        this.sabor = sabor;
    }
        
    
}
